package Banking_Management_system;

import javax.swing.*;//swing- comes from extend java package
import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;

public class Login extends JFrame implements ActionListener {//jframe is a class that we can import from swing

    JButton signin, signup, clear;
    JTextField cardtxtfield;
    JPasswordField pintxtfield;
    Login(){

        setTitle("Automated Teller Machine");//give title to the jframe

        setLayout(null);//we have to set it to null(now origin is lefttopmost corner of the frame) otherwise it wil give bydefault position to the icon which is center
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("logo.jpg"));
        Image i2=i1.getImage().getScaledInstance(100,100,Image.SCALE_DEFAULT);//set the size of the icon
        ImageIcon i3=new ImageIcon(i2);
        JLabel label=new JLabel(i3);
        label.setBounds(70,10,100,100);//to set the custom dimensions
        add(label);

        JLabel text=new JLabel("Welcome to ATM");//here we use tha Jlable to write the text on the frame
        text.setFont(new Font("Osward", Font.BOLD, 38));//to set the font size we use setFont func and  here we call the new object of the font class
        text.setBounds(200,40,400,40);//to set the bound of the text
        add(text);

        JLabel cardno=new JLabel("Card No:");//here we use tha Jlable class to write the text on the frame
        cardno.setFont(new Font("Raleway", Font.BOLD, 28));//here we call tha obj(cardno) of the JLabel class to set the font size we use setFont func and  here we call the new object of the font class
        cardno.setBounds(120,150,250,30);//to set the bound of the text
        add(cardno);

        cardtxtfield=new JTextField();//to create textfield we can use JTextField class
        cardtxtfield.setBounds(300,150,250,30);
        cardtxtfield.setFont(new Font("Arial", Font.BOLD, 14));
        add(cardtxtfield);

        JLabel pin=new JLabel("PIN:");//here we use tha Jlable to write the text on the frame
        pin.setFont(new Font("Raleway", Font.BOLD, 28));//to set the font size we use setFont func and  here we call the new object of the font class
        pin.setBounds(120,220,250,30);//to set the bound of the text
        add(pin);

        pintxtfield=new JPasswordField();//here we use the JPasswordField class to create passwordfield
        pintxtfield.setBounds(300,220,250,30);
        pintxtfield.setFont(new Font("Arial", Font.BOLD, 14));
        add(pintxtfield);

        signin=new JButton("SIGN IN");//to create button we can use JButton clss
        signin.setBounds(300, 300, 100,30);
        signin.setBackground(Color.BLACK);//to set background color
        signin.setForeground(Color.WHITE);//to set forground color(text color)
        signin.addActionListener(this);
        add(signin);

        clear=new JButton("CLEAR");//jbutton class use to create the button
        clear.setBounds(450, 300, 100,30);
        clear.setBackground(Color.BLACK);//to set the background color of the button
        clear.setForeground(Color.WHITE);//to set the font color
        clear.addActionListener(this);
        add(clear);

        signup=new JButton("SIGN UP");
        signup.setBounds(300, 350, 250,30);
        signup.setBackground(Color.BLACK);
        signup.setForeground(Color.WHITE);
        signup.addActionListener(this);
        add(signup);


        setSize(800,480);//to set size of the frame
        setVisible(true);//by default visbilty to user is false if its false we cant see the window so we will set it to true
        setLocation(450,200);

        getContentPane().setBackground(Color.white);//to set the background color of the frame

    }

    public void actionPerformed(ActionEvent ae){//here we create ActionEvent class and object ae indicate that a component defined action occured
        if(ae.getSource()==clear){//here we call the getsource through object ae to determine which button was clicked
            cardtxtfield.setText("");//when we will click the buttn setText() function enter data manually
            pintxtfield.setText("");
        }
        else if (ae.getSource()==signin){
           conn c=new conn();
           String cardnumber=cardtxtfield.getText();
           String pinnumber=pintxtfield.getText();
           String query="select * from login1 where cardnumber = '"+cardnumber+"' and pinnumber = '"+pinnumber+"'";
           try{
               ResultSet rs=c.s.executeQuery(query);
               if(rs.next()){
                   setVisible(false);
                   new transaction(pinnumber).setVisible(true);
               }
               else{
                   JOptionPane.showMessageDialog(null,"Incorrect credentials");
               }
           }catch (Exception e){
               System.out.println(e);
           }
        }
        else if (ae.getSource()==signup){
            setVisible(false);//helps to destroy the login frame
            new signup1().setVisible(true);//calling the application from the frame

        }
    }

    public static void main(String[] args) {
        new Login();
    }
}
