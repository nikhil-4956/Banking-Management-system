package Banking_Management_system;
import java.sql.*;

public class conn {
    Connection c;
    Statement s;
    public  conn(){
        try{//mysql is used as a external entity so may be it will throw  during runtime to catch these error we are using exceptional handling
           // Class.forName(com.mysql.cj.jdbc.Driver);
            c=DriverManager.getConnection("jdbc:mysql:///bankmanagementsystem", "root", "1234");
            s=c.createStatement();//third step:create statement
        }catch (Exception e){
            System.out.println(c);

        }

    }
    public static void main(String[] args) {


    }
}
