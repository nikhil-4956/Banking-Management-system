package Banking_Management_system;

import javax.swing.*;
import java.awt.*;
import java.util.Random;
import com.toedter.calendar.JDateChooser;
import java.awt.event.*;

public class signup2 extends JFrame implements ActionListener {

    JTextField  adhaar, pan;
    JButton next;
    JRadioButton syes, sno, eyes, eno, male, female,other, married, unmarried;
    JComboBox religion,category,income,occupation, education,ocupation;
    String formno;

    signup2(String formno){
        this.formno=formno;

        setLayout(null);

        setTitle("NEW ACCOUNT APPLICATION FROM - PAGE 2");


        JLabel additionalDetails=new JLabel("Page 2 : Additional Details");
        additionalDetails.setFont(new Font("Raleway", Font.BOLD, 22));
        additionalDetails.setBounds(290,80,400,30);
        add(additionalDetails);

        JLabel name=new JLabel("Religion:");
        name.setFont(new Font("Raleway", Font.BOLD, 20));
        name.setBounds(100,140,100,30);
        add(name);

        String valreligion[]={"Hindu", "Muslim", "Sikh", "Christian", "Other"};//make an array of the item(insert in dropdown list)
        religion=new JComboBox(valreligion);//JcomboBox using to create dropdown
        religion.setBounds(300,140,400,30);
        religion.setBackground(Color.WHITE);
        add(religion);


        JLabel fname=new JLabel("Category:");
        fname.setFont(new Font("Raleway", Font.BOLD, 20));
        fname.setBounds(100,190,200,30);
        add(fname);

        String valcategory[]={"General", "SC", "ST", "Other"};
        category=new JComboBox(valcategory);
        category.setBounds(300,190,400,30);
        category.setBackground(Color.white);
        add(category);


        JLabel dob=new JLabel("Income:");
        dob.setFont(new Font("Raleway", Font.BOLD, 20));
        dob.setBounds(100,240,200,30);
        add(dob);

        String valincome[]={"Null", "<1,50,000", "<2,50,000", "<5,00,000", "upto 10,00,000"};
        income=new JComboBox(valincome);
        income.setBounds(300,240,400,30);
        income.setBackground(Color.white);
        add(income);


        JLabel gender=new JLabel("Educational");
        gender.setFont(new Font("Raleway", Font.BOLD, 20));
        gender.setBounds(100,290,200,30);
        add(gender);
        JLabel email=new JLabel("Qualification:");
        email.setFont(new Font("Raleway", Font.BOLD, 20));
        email.setBounds(100,315,200,30);
        add(email);

        String educationValues[]={"Graduate", "Post Graduate", "Non Graduate", "Other"};
        education=new JComboBox(educationValues);
        education.setBounds(300,290,400,30);
        education.setBackground(Color.white);
        add(education);


        JLabel marital=new JLabel("Occupation:");
        marital.setFont(new Font("Raleway", Font.BOLD, 20));
        marital.setBounds(100,390,200,30);
        add(marital);

        String OccupationalValues[]={"Self-Employed", "Business", "Student", "Retired", "Other"};
        ocupation=new JComboBox(OccupationalValues);
        ocupation.setBounds(300,390,400,30);
        ocupation.setBackground(Color.white);
        add(ocupation);


        JLabel panno=new JLabel("PAN Number:");
        panno.setFont(new Font("Raleway", Font.BOLD, 20));
        panno.setBounds(100,440,200,30);
        add(panno);

        pan=new JTextField();
        pan.setFont(new Font("Raleway", Font.BOLD, 14));
        pan.setBounds(300,440,400,30);
        add(pan);


        JLabel city=new JLabel("Adhaar Number:");
        city.setFont(new Font("Raleway", Font.BOLD, 20));
        city.setBounds(100,490,200,30);
        add(city);

        adhaar=new JTextField();
        adhaar.setFont(new Font("Raleway", Font.BOLD, 14));
        adhaar.setBounds(300,490,400,30);
        add(adhaar);


        JLabel state=new JLabel("Senior Citizen:");
        state.setFont(new Font("Raleway", Font.BOLD, 20));
        state.setBounds(100,540,200,30);
        add(state);

        syes=new JRadioButton("Yes ");
        syes.setBounds(300,540,120,30);
        syes.setBackground(Color.white);
        add(syes);

        sno=new JRadioButton("No");
        sno.setBounds(450,540,120,30);
        sno.setBackground(Color.white);
        add(sno);

        ButtonGroup gendergroup=new ButtonGroup();//use here so that we can click one radiobutton at a time
        gendergroup.add(syes);
        gendergroup.add(sno);


        JLabel Pincode=new JLabel("Existing Account:");
        Pincode.setFont(new Font("Raleway", Font.BOLD, 20));
        Pincode.setBounds(100,590,200,30);
        add(Pincode);

        eyes=new JRadioButton("Yes ");
        eyes.setBounds(300,590,120,30);
        eyes.setBackground(Color.white);
        add(eyes);

        eno=new JRadioButton("No");
        eno.setBounds(450,590,120,30);
        eno.setBackground(Color.white);
        add(eno);

        ButtonGroup marritalgroup=new ButtonGroup();//use here so that we can click one radiobutton at a time
        marritalgroup.add(eyes);
        marritalgroup.add(eno);


        next= new JButton("Next");
        next.setBackground(Color.BLACK);
        next.setForeground(Color.WHITE);
        next.setFont(new Font("Raleway", Font.BOLD, 14));
        next.setBounds(620,660,80,30);
        next.addActionListener(this);
        add(next);

        getContentPane().setBackground((Color.white));

        setSize(850,800);
        setLocation(350,10);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae){

        String sreligion=(String) religion.getSelectedItem();
        String scategory= (String) category.getSelectedItem();
        String sincome=(String) income.getSelectedItem();
        String seducation=(String) education.getSelectedItem();
        String soccupation=(String) ocupation.getSelectedItem();
        String span=pan.getText();
        String sadhaar=adhaar.getText();
        String seniorcitizen=null;
        if(syes.isSelected()){//check if male is selected then it store in databe
            seniorcitizen="Yes";
        }
        else if(sno.isSelected()){//if female then
            seniorcitizen="No";
        }
        String existingaccount=null;
        if(eyes.isSelected()){
            existingaccount="Yes";
        }
        else if(eno.isSelected()){
            existingaccount="No";
        }

        try{
                conn c=new conn();
                String query="insert into signuptwo values (' " +formno+" ' , ' " +sreligion+"' , ' " +sincome+"', ' " +soccupation+"' , ' " +seducation+"' , ' " +scategory+"' , ' " +sadhaar+ "' , ' " +span+ "' , ' " +seniorcitizen+"' , ' " +existingaccount+"' )";
                c.s.executeUpdate(query);


                setVisible(false);
                new signup3(formno).setVisible(true);

        }catch (Exception e){
            System.out.println(e);
        }


    }
    public static void main(String[] args) {
        new signup2("");
    }

}
