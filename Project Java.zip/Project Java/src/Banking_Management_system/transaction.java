package Banking_Management_system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.*;

public class transaction extends JFrame implements ActionListener {
    JButton deposit, withdrawl, fastcash, ministatement, pinchange,balanceenquiry, exit;
    String pinnumber;
    transaction(String pinnumber){
        this.pinnumber=pinnumber;
        setLayout(null);

        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("atm.jpg"));
        Image i2=i1.getImage().getScaledInstance(900,800, Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel image=new JLabel(i3);
        image.setBounds(0,0,900,800);
        add(image);

        JLabel text=new JLabel("Please select your transaction");
        text.setBounds(220,250,700,35);
        text.setForeground(Color.white);
        text.setFont(new Font("Raleway", Font.BOLD,16));
        image.add(text);//image.add(txt) use to write the text on the image


        deposit=new JButton("Deposit");
        deposit.setBounds(170,370,150,25);
        deposit.addActionListener(this);
        image.add(deposit);

        withdrawl=new JButton("Cash Withdrawl");
        withdrawl.setBounds(355,370,150,25);
        withdrawl.addActionListener(this);
        image.add(withdrawl);

        fastcash=new JButton("Fast Cash");
       fastcash.setBounds(170,400,150,25);
        fastcash.addActionListener(this);
        image.add(fastcash);

        ministatement=new JButton("Mini Statement");
        ministatement.setBounds(355,400,150,25);
        ministatement.addActionListener(this);
        image.add(ministatement);

        pinchange=new JButton("Pin Change");
        pinchange.setBounds(170,430,150,25);
        pinchange.addActionListener(this);
        image.add(pinchange);

        balanceenquiry=new JButton("Balance Enquiry");
        balanceenquiry.setBounds(355,430,150,25);
        balanceenquiry.addActionListener(this);
        image.add(balanceenquiry);

        exit=new JButton("Exit");
        exit.setBounds(355,460,150,25);
        exit.addActionListener(this);
        image.add(exit);


        setSize(900,800);
        setLocation(300,0);
        setUndecorated(true);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==exit){
            System.exit(0);

        } else if (ae.getSource()==deposit) {
            setVisible(false);
            new deposit(pinnumber).setVisible(true);

        }
        else if (ae.getSource()==withdrawl) {
            setVisible(false);
            new withdrawl(pinnumber).setVisible(true);

        }
        else if(ae.getSource()==fastcash){
            setVisible(false);
            new fastcash(pinnumber).setVisible(true);
        }


    }
    public static void main(String[] args) {
        new transaction("");


    }
}
